﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Контакты.</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="/favicon.ico" />
</head>
<body>
<? include ("block/header.php");?>
<? include ("block/nav.php");?>
<div class="content">
<h1>Контакты</h1>
 <div class="goroda">
 <p>Для связи с администрацией сайта используйте следующие контактные данные:</p>
 
 <p style="padding-left: 90px;"><strong>e-mile: <img class="alignnone size-full wp-image-1553" src="http://reytingi.com/wp-content/uploads/2014/10/mail.jpg" alt="mail" width="300" height="40" /></strong></p>
<br />
<p style="padding-left: 90px;"><strong>skype:<img class="alignnone size-full wp-image-1552" src="http://reytingi.com/wp-content/uploads/2014/10/skype.jpg" alt="skype" width="147" height="40" /></strong></p>



 </div>
<div id="clear"> </div>
</div>
<? include ("block/footer.php");?>
		  </div><!-- #content-->

</body>
</html>
