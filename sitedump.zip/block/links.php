﻿<ul>
<li><a href="../map/<?=$myrow['chpu'];?>">Карта <?=$myrow['rpadej'];?></a></li>
<li><a href="../photo/<?=$myrow['chpu'];?>">Фото <?=$myrow['rpadej'];?></a></li>
<li><a href="../panoram/<?=$myrow['chpu'];?>">Панорама <?=$myrow['rpadej'];?></a></li>
<li><a href="../probki/<?=$myrow['chpu'];?>">Пробки <?=$myrow['rpadej'];?></a></li>
Сервисы:
<li><a href="../avtomoyka/<?=$myrow['chpu'];?>">Автомойки</a></li>
<li><a href="../sto/<?=$myrow['chpu'];?>">Автосервисы</a></li>
<li><a href="../parking/<?=$myrow['chpu'];?>">Автопарковки</a></li>
</ul>