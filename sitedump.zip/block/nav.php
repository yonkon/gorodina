﻿<div class="title">
  <a href="/">ГЛАВНАЯ</a>
  <a href="/vibor-goroda.php">ВЫБРАТЬ ГОРОД</a>
  <a href="/maps.php">КАРТЫ</a>
  <a href="/panorami.php">ПАНОРАМЫ</a>
  <a href="/photo.php">ФОТО</a>
  <a href="/probki.php">ПРОБКИ</a>
 </div>