﻿<div class="header">
	<p><span style="color:#FFFFFF">Go</span><span style="color:#4D7DEB">Rodina</span><span style="color:#FF0000">.ru</span> - яркий взгляд на наши города.</p>
</div>