<?
$db = mysql_connect ("localhost","p155930_gorodina","O=oFXC.kU4?x");
mysql_select_db("p155930_gorodina",$db);

mysql_query('SET NAMES utf-8');
mysql_query ("set character_set_results='utf-8'")
?>